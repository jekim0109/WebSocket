using WebSocketSharp;
using WebSocketSharp.Server;
 
namespace websocket
{
    public partial class MainWindow : Window
    {
        private static MainWindow g_Main = null;
        public static MainWindow getWindow
        {
            get
            {
                return g_Main;
            }
        }
 
        public void addText(string text)
        {
            this.Dispatcher.Invoke((Action)(() =>
            {
                string myText = Console.Text;
                myText += text;
                Console.Text = myText;
            }));
        }
 
        public MainWindow()
        {
            InitializeComponent();
            g_Main = this;
        }
        private WebSocketServer webSocketServer = null;
 
        private void Start_Click(object sender, RoutedEventArgs e)
        {
            if (webSocketServer != null)
                return;
 
            Int32 port = 4649;
            webSocketServer = new WebSocketServer(port);
            webSocketServer.AddWebSocketService<Echo>("/Echo");
            webSocketServer.AddWebSocketService<Chat>("/Chat");
            webSocketServer.Start();
            Console.Text += "서버시작\n";
        }
 
        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            if (webSocketServer != null)
                webSocketServer.Stop();
 
            webSocketServer = null;
            Console.Text += "서버종료\n";
        }
    }
}
