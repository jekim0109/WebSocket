﻿using System;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace WebSocket_Server
{
    public class Chat : WebSocketBehavior
    {
        protected override void OnMessage(MessageEventArgs e)
        {
            var text = e.Data;
            text += "\n";
            MainWindow.getWindow.addText(text);

            Sessions.Broadcast(e.Data);
        }
    }
}
