﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WebSocket_Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private static MainWindow _mainWindow = null;
        public static MainWindow mainWindow
        {
            get
            {
                return _mainWindow;
            }
        }
        private Client client;
        public MainWindow()
        {
            InitializeComponent();
            _mainWindow = this;
            client = new Client();
        }

        public void recvMsg(string text)
        {
            this.Dispatcher.Invoke(() =>
            {
                RecvBox.Text += "\n";
                RecvBox.Text += text;
            });
        }

        private void sendButton_Click(object sender, RoutedEventArgs e)
        {
            client.SendMessage(sendBox.Text);
            sendBox.Text = "";
        }
    }

}
