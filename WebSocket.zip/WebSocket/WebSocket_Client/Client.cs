﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using WebSocketSharp;

namespace WebSocket_Client
{
    public class Client
    {
        private WebSocket mWebSocket;
        public Client()
        {
            StartConnect();
        }
        public void StartConnect()
        {
            mWebSocket = new WebSocket("ws://localhost:4649/Chat");
            //mWebSocket = new WebSocket("ws://192.168.0.21:14649/Chat");
            mWebSocket.OnOpen += (sender, e) =>
            {
                //mWebSocket.Send("Hi, there!");
            };
            mWebSocket.OnMessage += (sender, e) =>
            {
                MainWindow.mainWindow.recvMsg(e.Data);
            };
            mWebSocket.Connect();
        }
        public void SendMessage(string msg)
        {
            try
            {
                mWebSocket.Send("nickname: " + msg);
            }
            catch (Exception e)
            {
                MessageBox.Show("애러 났슈" + e.Message);
            }

        }
    }
}
